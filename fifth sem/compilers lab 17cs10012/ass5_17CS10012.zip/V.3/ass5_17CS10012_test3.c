int test = 2;
void main () 
{
	int i, a[25], v = 5;
	float d;
	for (i=1;i<24;i++) 
		i++;
	do {
		i = i - 1;
	} while (a[i] < v);
	while(i<5)
	{
		j=i+5;
	}
	i = 3;
	if (i&&v) 
		i = 1;
	else if(j==1)
		j=2;
	else
	{
		if(j==2)
		{
			j=4;
		}
		else
		{
			j=5;
		}
	}
	return;
}
