// TEST 6
// Declaration Phase
int test = 2;
float d = 1.25;
int i, w[25];
int a = 1, *p, b;
void func(int i, float d);
char c;

int main () {
	float e = 1.414;
	int f, w[8];
	int r = 5, *q, y;
	char h;
}
