Expressions
	Compound assignment operations
	structures component expression
	Sizeof operator
	Comma operator supported

Declarations
	array initialization
	storage-class specifier enum specifier type qualifier function specifier
	function declaration with only parameter type list

Statement
	declaration within for
	labelled statements
	switch statements
	jump statement except return

External definitions
	External declarations	
 
