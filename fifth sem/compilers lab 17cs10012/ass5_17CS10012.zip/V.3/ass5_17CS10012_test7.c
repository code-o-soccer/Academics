// Test Expressions
int test = 1;
int main () {
	int a=1, b=2, c;
	c = a + b;
	a++;
	int check = a+b*c;
	if (check < c) 
		c = a|b;
	i = ++a;
}
