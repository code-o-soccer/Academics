/*
Name :- Divyang Mittal
Roll no. :- 17cs10012
Assignment - 3
*/
#include <stdio.h>

// Code for each lexer element
#define ESCAPE_SEQUENCE 1
#define PUNCTUATOR 2
#define KEYWORD 3
#define COMMENT 4
#define IDENTIFIER 5
#define ENU_CONSTANT 6
#define CHARACTER 7
#define STRING 8
#define INTEGER 9
#define FLOAT_CONST 10
#define COMMENT_END 11

extern char* yytext;

int main()
{
	int token;
	char comment[3];
	int last = 0;
	token = yylex();
	while(token)
	{
		switch(token)
		{
			case ESCAPE_SEQUENCE:
				printf("<ESCAPE_SEQUENCE, %d, %s>\n", token, yytext);
				break;

			case PUNCTUATOR:
				printf("<PUNCTUATOR, %d, %s>\n", token, yytext);
				break;

			case KEYWORD:
				printf("<KEYWORD, %d, %s>\n", token, yytext);
				break;

			case COMMENT:
				last = 0;
				comment[0] = yytext[0];
				comment[1] = yytext[1];
				break;

			case COMMENT_END:
				last = 1;
				printf("<COMMENT, %d, %s>\n", token, comment);
				break;

			case IDENTIFIER:
				printf("<IDENTIFIER, %d, %s>\n", token, yytext);
				break;

			case ENU_CONSTANT:
				printf("<ENUMERATION_CONSTANT, %d, %s>\n", token, yytext);
				break;

			case CHARACTER:
				printf("<CHARACTER, %d, %s>\n", token, yytext);
				break;

			case STRING:
				printf("<STRING, %d, %s>\n", token, yytext);
				break;

			case INTEGER:
				printf("<INTEGER, %d, %s>\n", token, yytext);
				break;

			case FLOAT_CONST:
				printf("<FLOATING_CONSTANT, %d, %s>\n", token, yytext);
				break;

			default :
				printf("<PUNCTUATOR, %d, %s>\n", token, yytext);
				break;
		}
		token = yylex();
	}
	if(last == 0)
		printf("Improper commenting\n");
}
