/*
Name :- Divyang Mittal
Roll no. :- 17cs10012
Assignment - 3
*/
make 

// to run a test file
make test

// to delete a test file
make clean