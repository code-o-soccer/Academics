/*
Name :- Divyang Mittal
Roll no. :- 17cs10012
Assignment - 4
*/
#include <stdio.h>
#include "y.tab.h"

extern int yyparse();
extern char *yytext;

int main()
{
    int token;
    yyparse();
    return 0;
}