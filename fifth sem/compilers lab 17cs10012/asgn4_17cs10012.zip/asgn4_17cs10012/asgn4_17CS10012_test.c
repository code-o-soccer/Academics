/*
Name :- Divyang Mittal
Roll no. :- 17cs10012
Assignment - 4
*/
int main () 
{ 
    i++;
    a=b+c*f^b&&e||f;
    for(i=0;i<n;i++)
    {
    	j=j^t;
    }
    return ;
}