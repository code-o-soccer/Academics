/*
Name - Divyang Mittal
Roll no. - 17cs10012
Assignment - 2
*/

#include "myl.h"

// main function 
int main()
{
    int option,number;
    float fvalue;
    printStr("\n Enter a choice according to following options!");
    printStr("\n 1.Read an integer and print it\n");
    printStr("\n 2.Read a float value and print it\n");
    printStr("\n 3.Exit from the function \n");
    for( ; 1; )
    {
        printStr("Enter choice:");
        if(readInt(&option)==ERR)
        {
            printStr("Invalid choice, re-enter: ");
            continue;
        }
        switch(option)
        {
            case 1:   printStr("Enter int: ");
                      if(readInt(&number)==ERR)
                      {
                          printStr("Error:Input is not an integer \n");
                          continue;
                      }
                      else 
                          printStr("Following integer read:\n");
                      printInt(number);
                      printStr("\n");
                      break;
            case 2:   printStr("Enter float: \n");
                      if(readFlt(&fvalue)==ERR)
                      {
                          printStr("Error:Input is not a float\n");
                          continue;
                      }
                      else 
                          printStr("Following float read:\n");
                      printFlt(fvalue);
                      printStr("\n");
                      break; 
            case 3:
                      return 0;
            default:  break;    
        }
    }
    return 0;
}