/*
Name - Divyang Mittal
Roll no. - 17cs10012
Assignment - 2
*/
#include "myl.h"
#define SYS_READ 0
#define STDIN_FILENO 0

// Function to print a string
int printStr(char *s)
{
    int i,length_string;
    for(i = 0; s[i] != '\0'; )              // Calculating the length of input string
    {
        i++;
    }
    length_string = i;
    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"               // Calling the function to print string
        "movq $1, %%rdi \n\t" 
        "syscall \n\t"
        :
        :"S"(s), "d"(length_string)         
    );
    return length_string;                   // returning the length of the string 
}

// Function to print an integer number
int printInt(int n)
{
    int i, j, bytes, k;
    char buff[100],ch;
    i = 0;
    if(n < 0)                                // Checking for negative number
    {
        n=-n;
        buff[i] = '-';
        i++;
    }
    if(n == 0)                               // Handling corner case of n = 0
    {
        buff[i] = '0';
        i++;
    }
    for( ; n != 0; i++)                      // Converting the number into a character array
    {
        buff[i] = (char)(n%10 + '0');
        n = n/10;
    }
    if(buff[0] == '-')                       // initializing the starting point of character array  
    {
        j = 1;
    }
    else
    {
        j = 0;
    }
    k = i-1;                                  
    bytes = i;                               // calculating length of number
    for( ; j<k; j++, k--)                    // reversing the buff array
    {
        ch = buff[k];
        buff[k] = buff[j];
        buff[j] = ch;

    }
  __asm__ __volatile__ (                     // calling function to print thee buff array 
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(buff), "d"(bytes)
    );
    return bytes;
}

// Function to input an integer
int readInt(int *n)
{
    int i, j, length_input, num, neg, read_int;
    char buff[100];
    asm volatile(                                   // storing the integer input into buff array and length in length_input
    "syscall" : "=a" (length_input) 
    : "0" (SYS_READ), "D" (STDIN_FILENO), "S" (buff), "d" (sizeof(buff))
    : "rcx", "r11", "memory", "cc");
    j = length_input - 1;                           
    buff[j] = 0x0;                                  // storing a terminating value
    for(i = j-1; i >= 0; i--)                       // checking for spaces at the end of array
    {
        if(buff[i] != ' ')
            break;            
    }
    i = j - 1;
    while(i >= 0 && buff[i--] == ' ');     
    buff[i+2] = 0x0;
    length_input = i+2;                             // resizing hte size of input array
    for(i = 0; ; i++)                               // checking for spaces at the end of array
    {
        if(buff[i] != ' ')
            break;            
    }           
    if(buff[i] != '-')                              // checking for negative input
    {
        neg = 0;
    }      
    else
    {
        neg = 1;
        i++;
    }
    num = 0;                             
    for( ; i < length_input; i++)                    // building the number from array                       
    {             
        if(buff[i] < '0' || buff[i] > '9')           // returning an error if any other character is found than digits    
            return ERR;
        num = num * 10 + (buff[i]-'0');
    }       
    if(neg == 1)                                     // correcting the sign of the numberS 
        read_int = -num; 
    else
        read_int = num;            
    *n = read_int;                                   // storing the number     
    return OK; 
}

// Function to input a float value
int readFlt(float *f)
{
    int i, j, length_input, neg, dec_present, int_part;
    char buff[100];                
    float fact, dec_part, number, read_float;
    asm volatile("syscall"                            // storing the float input into buff array and length in length_input
      : "=a" (length_input) 
      : "0" (SYS_READ), "D" (STDIN_FILENO), "S" (buff), "d" (sizeof(buff))
      : "rcx", "r11", "memory", "cc"
    );
    j = length_input - 1;
    buff[j] = 0x0;                                    // storing a terminating value          
    for(i = j-1; i >= 0; i--)                         // checking for spaces at the end of array
    {
        if(buff[i] != ' ')
            break;            
    }
    buff[i+1] = 0x0;                                
    length_input = i+1;                               // resizing the array    
    for(i = 0;  ; i++)
    {
        if(buff[i] != ' ')
            break;            
    }           
    if(buff[i] != '-')                                // checking for negative input
    {
        neg = 0;
    }      
    else
    {
        neg = 1;
        i++;
    }
    int_part = 0;   
    dec_present = 0;
    dec_part = 0;
    fact = 0.1;
    for( ;i < length_input; i++)
    {                      
        if(buff[i] == '.')                          // checking for decimal point and ensuring only one is present
        {               
            if(dec_present == 1)
                return ERR;    
            dec_present = 1;
        }
        else if(buff[i] < '0' || buff[i] > '9')     // returning error if any other character than digits
        {    
            return ERR;
        }     
        else if(dec_present == 1)
        {
            dec_part = dec_part + fact * (buff[i]-'0');                 
            fact = fact * 0.1;
        }
        else
        {
            int_part = int_part * 10 + ( buff[i] - '0');                  
        }
    }  
    number = int_part + dec_part;                   // adding integral and decimal part to get the number  
    if(neg == 1)
        read_float = -number;                       // correcting the sign of the number
    else
        read_float = number;                                           
    *f = read_float;                                // storing the float value                                                        
    return OK;
}


// Function to print a float value
int printFlt(float f)
{
    int i, int_part, len, temp2;
    char buff[100];                
    float dec_part = 0, temp_float;
    int_part = (int)f;                              // calculating the integral part
    i = 1;
    len = 7;
    temp_float = f - (float)int_part;    
    if(f < 0 && int_part == 0)                      // printing - sign for negative input
        printStr("-");          
    len = len + printInt(int_part);                 // printing the integer part using printInt function
    if(temp_float < 0)                              // finding absolute value of decimal part
        dec_part = -temp_float;
    else
        dec_part = temp_float;                    
    buff[0] = '.';                                      
    for( ; i <= 6; i++)                             // converting the decimal part into a float array
    {
        if(dec_part <= 0)
            break;
        dec_part = dec_part * 10;
        temp2 = (int)dec_part;
        buff[i] = temp2 + '0';
        dec_part = dec_part - temp2;
    }   
    for( ;i<=6;i++)                                 // copying the remainig digits as zero
    {
        buff[i] = '0';
        if( i > 6)
            break;
    }
    buff[i] = '\0';                                 // adding a null symbol                        
    printStr(buff);                                 // printing the decimal part using printString function
    return len; 
}

